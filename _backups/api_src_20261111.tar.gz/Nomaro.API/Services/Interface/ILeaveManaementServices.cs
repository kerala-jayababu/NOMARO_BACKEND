﻿using Nomaro.API.DTO;

namespace Nomaro.API.Services.Interface
{
    public interface ILeaveManaementServices
    {
        Task<IEnumerable<LeaveTypesDto>> GetLeaveTypes();
        Task<IEnumerable<LeaveTypesDto>> GetLeaveTypesEmployee(int idEmployee, int idYear);
        Task<bool> AddOrUpdateLeaveTypes(LeaveTypesDto leaveTypeDto);
        Task<IEnumerable<LeaveTemplateDto>> GetLeaveTemplates(int? IdYear, string Status, string? searchText = null);
        Task<LeaveTemplateDto> GetLeaveTemplateByID(int idLeaveTemplate);
        Task<bool> AddUpdateLeaveTemplate(LeaveTemplatePostDto dto, int loggedInEmployeeId);

        Task<bool> SubmitLeaveTemplateForApproval(int idLeaveTemplate,   int loggedInEmployeeId);
        Task<bool> ApproveLeaveTemplate(int idLeaveTemplate, string approvalStatus, int loggedInEmployeeId);

        Task<bool> AddOrUpdateLeaveTemplateDetails(LeaveTemplateDetailsDto dto, int loggedInEmployeeId);
        Task<LeaveTemplateDetailsDto> GetLeaveTemplateDetailById(int idLeaveTemplateDetails);
        Task<List<EmployeeLeaveSetupDto>> GetEmployeesLeaveSetup(string? searchText, int? IdYear, string? ApprovalStatus);
        Task<EmployeeLeaveSetupDto> GetLeaveSetupOfAnEmployee(int idEmployee, int? idYear, DateTime? dateTo);
        Task<List<EmpLeaveConfigDetailsDto>> GetEmployeesLeaveConfigStatusDetails(int idWorkYear, int? IdDepartment, int? IdDesignation);

        Task<bool> AddUpdateEmployeeLeaveConfig(EmployeeLeaveConfigsPostDto dto, int loggedInEmployeeId);
        Task<bool> SubmitEmployeeLeaveConfigForApproval(int IdEmployeeLeaveConfig, int loggedInEmployeeId);
        Task<bool> ApproveEmployeeLeaveConfig(int IdEmployeeLeaveConfig, string approvalStatus, int loggedInEmployeeId);
        Task<bool> ApproveEmployeeLeaveConfigMultiple(List<int> IdEmployeeLeaveConfigs, string approvalStatus, int loggedInEmployeeId, string? reason);
        Task<List<int>> GetEmployeeLeaveConfigApprovers();
        Task<List<int>> GetLeaveTemplateApprovers();

        Task<bool> AddUpdateEmployeeLeaveConfigDetails(EmployeeLeaveConfigDetailsPostDto dto, int loggedInEmployeeId);
        Task<PagedResultDto<LeaveApplicationListDto>> GetLeaveApplications(
            int loggedInEmployeeId,
            int? idEmployee,
            string? approvalStatus,
            string? applicationStatus,
            DateTime? fromDate,
            DateTime? toDate,
            int? idLeaveType,
            string? SearchText,
            PagingRequestDto paging);

        Task<LeaveApplicationDetailsDto> GetLeaveApplication(int idLeaveApplication);
        Task<LeaveApplicationSaveResultDto> AddUpdateLeaveApplication(LeaveApplicationPostDto dto, int loggedInEmployeeId);
        Task<bool> DeleteLeaveApplicationDocument(int idLeaveApplicationDocument, int loggedInEmployeeId, bool isHrOverride);
        Task<CancelLeaveApplicationResultDto> CancelLeaveApplication(int idLeaveApplication, string? cancelReason, int loggedInEmployeeId);
        Task<IEnumerable<LeaveApplicationListDto>> GetLeaveApplicationsForApproval(int loggedInEmployeeId, string? approvalStatus, string? SearchText, DateTime? fromDate);
        Task<List<LeaveDashboardDto>> GetLeaveDashboardEmployee(int idEmployee, int idYear);
        Task<List<LeaveApplicationListDto>> GetLeaveApplicationsEmployee(int idEmployee, DateTime DateFrom, DateTime DateTo);
        Task<List<MonthlyLeaveDashboardDto>> GetLeaveDashboardEmployeeMonthWise(int idEmployee, int idYear);
        Task<decimal> CalculateLeaveDaysAsync(bool IncludeHoliday, DateTime fromDate, DateTime toDate, bool isHalfDay);
        Task<bool> SubmitLeaveApplicationApproval(List<int> idChanges, string approvalStatus, string? remarks, int loggedInEmployeeId);
        Task<List<LeaveApplicationDocumentDto>> GetLeaveApplicationDocuments(int idLeaveApplication);
        Task<bool> DeleteLeaveTemplateDetail(int idLeaveTemplateDetail);
        Task<List<EmployeeNameList>> GetEmployeesNotConfiguredLeave(int idWorkYear);
        Task<int> AddUpdateEmployeeLeaveConfigWithDetails(EmployeeLeaveConfigWithDetailsPostDto dto, int loggedInEmployeeId);

        Task<List<LeaveTemplateApplyResult>> ApplyLeaveTemplateToMultipleEmployees(List<int> Idemployees, int IdLeaveTemplate, int IdYear, int loggedInEmployeeId);
        Task<TodayAtAGlanceDto> GetTodaySummaryAsync(DateTime date);
        Task<List<LeaveRequestRowDto>> GetLeaveRequestsAsync(DateTime? from, DateTime? to, int? idDepartment, int? idDesignation, string status, string search);
        Task<List<NotClockedEmployeeWithShiftDto>> GetNotClockedInWithShiftAsync(DateTime date);
        Task<List<LeaveRequestRowDto>> GetTodayStatusDetails(DateTime Date, string QueryType);

        Task<LeaveKpiSummaryDto> GetKpiSummaryAsync(int idYear);
        Task<IEnumerable<LeaveByTypeDto>> GetLeaveByTypeAsync(int idYear);
        Task<IEnumerable<MonthlyLeaveTrendDto>> GetMonthlyTrendAsync(int idYear);
        Task<IEnumerable<DepartmentLeaveDto>> GetDepartmentSummaryAsync(int idYear);
        Task<IEnumerable<DesignationLeaveDto>> GetDesignationSummaryAsync(int idYear);
        Task<IEnumerable<EmployeeLeaveDetailDto>> GetEmployeeLeaveDetailsAsync(int idYear, int IdDepartment, int IdDesignation);


    }
}

