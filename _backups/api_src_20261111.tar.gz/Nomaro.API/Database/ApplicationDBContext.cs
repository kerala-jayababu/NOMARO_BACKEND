using Nomaro.API.DTO;
using Nomaro.API.Models;
using Nomaro.API.Models.Shift;
using Nomaro.API.Models.Time___Attendance.Bamboo_HR;
using Nomaro.API.Models.Time___Attendance.Shift;
using Nomaro.API.Models.YourNamespace.Models;
using Nomaro.API.Services.Implimentation.Time___Attendance.BambooHR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Nomaro.API.Database
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {
        }

        public DbSet<BudgetCodeEntity> BudgetCodes { get; set; }
        public DbSet<DesignationEntity> Designations { get; set; }
        public DbSet<Grades> Grades { get; set; }
        public DbSet<ProfileChangeRequestTypes> ProfileChangeRequestTypes { get; set; }
        public DbSet<ProfileChangeRequests> ProfileChangeRequests { get; set; }
        public DbSet<ProfileChangeRequestDetails> ProfileChangeRequestDetails { get; set; }
        public DbSet<ProfileChangeRequestDocuments> ProfileChangeRequestDocuments { get; set; }
        public DbSet<EmployeeAgreements> EmployeeAgreements { get; set; }
        public DbSet<EmployeeAgreementTokens> EmployeeAgreementTokens { get; set; }
        public DbSet<EmployeeAgreementEvents> EmployeeAgreementEvents { get; set; }
        public DbSet<EmployeeFamilyMembers> EmployeeFamilyMembers { get; set; }
        public DbSet<GeneralDocumentTypes> GeneralDocumentTypes { get; set; }
        public DbSet<GeneralDocumentSubtypes> GeneralDocumentSubtypes { get; set; }
        public DbSet<GeneralDocuments> GeneralDocuments { get; set; }
        public DbSet<GeneralDocumentRecords> GeneralDocumentRecords { get; set; }
        public DbSet<GeneralDocumentFiles> GeneralDocumentFiles { get; set; }
        public DbSet<GeneralDocumentAudit> GeneralDocumentAudit { get; set; }
        public DbSet<GeneralDocumentAcknowledgements> GeneralDocumentAcknowledgements { get; set; }
        public DbSet<DepartmentEntity> Departments { get; set; }
        public DbSet<SalaryHeads> SalaryHeads { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Banks> Banks { get; set; }
        public DbSet<EmployeeBankAccount> EmployeeBankAccounts { get; set; }
        public DbSet<EmployeeOvertimeConfig> EmployeeOvertimeConfig { get; set; }
        public DbSet<BankBranches> BankBranches { get; set; }
        public DbSet<PayrollScreens> PayrollScreens { get; set; }
        public DbSet<EmployeePermissions> EmployeePermissions { get; set; }
        public DbSet<RoleBasedPermission> RoleBasedPermissions { get; set; }
        public DbSet<SystemParameter> SystemParameters { get; set; }
        public DbSet<NotificationConfig> NotificationsConfig { get; set; }
        public DbSet<VacationMode> VacationModes { get; set; }
        public DbSet<TaxSlab> TaxSlabs { get; set; }
        public DbSet<FinancialYears> FinancialYears { get; set; }
        public DbSet<WorkYears> WorkYears { get; set; }
        public DbSet<CurrencyConversion> CurrencyConversions { get; set; }
        public DbSet<TaxYearConfigs> TaxYearConfigs { get; set; }
        public DbSet<SalaryTemplate> SalaryTemplates { get; set; }
        public DbSet<SalaryTemplateDetails> SalaryTemplateDetails { get; set; }
        public DbSet<OvertimeTransactionEntity> OvertimeTransactions { get; set; }
        public DbSet<SalaryAdjustment> SalaryAdjustments { get; set; }
        public DbSet<ScheduledSalaryDeduction> ScheduledDeductions { get; set; }
        public DbSet<ScheduledDeductionDetails> ScheduledDeductionDetails { get; set; }
        public DbSet<MaternityLeaveSalaryEntity> MaternityLeaveSalaries { get; set; }
        public DbSet<RentFreeQuarter> RentFreeQuarters { get; set; }
        public DbSet<OvertimeTypes> OvertimeTypes { get; set; }
        public DbSet<EmployeeSalaryConfigDetails> EmployeeSalaryConfigDetails { get; set; }
        public DbSet<EmployeeSalaryConfig> EmployeeSalaryConfig { get; set; }
        public DbSet<SalaryMonths> SalaryMonths { get; set; }
        public DbSet<MaternityLeaveSalaryDetail> MaternityLeaveSalaryDetail { get; set; }
        public DbSet<HolidayTypeEntity> HolidayTypes { get; set; }
        public DbSet<Holiday> Holidays { get; set; }
        public DbSet<WorkFlowConfig> WorkFlowConfig { get; set; }
        public DbSet<WorkFlowConfigDetails> WorkFlowConfigDetails { get; set; }
        public DbSet<ApprovalWorkFlowAllocation> ApprovalWorkFlowAllocations { get; set; }
        public DbSet<EmployeeSalaries> EmployeeSalaries { get; set; }
        public DbSet<EmployeesForSalaryGenerationStatus> EmployeesForSalaryGenerationStatus { get; set; }
        public DbSet<RentFreeQuarterDurations> RentFreeQuarterDurations { get; set; }
        public DbSet<EmployeeSalaryDetails> EmployeeSalaryDetails { get; set; }
        public DbSet<LeavePassage> LeavePassages { get; set; }
        public DbSet<ReportsMaster> ReportsMaster { get; set; }
        public DbSet<ReportConditions> ReportConditions { get; set; }
        public DbSet<ReportColumns> ReportColumns { get; set; }

        public DbSet<Notification> Notifications { get; set; }
        public DbSet<LoginOTP> LoginOTP { get; set; }
        public DbSet<BankRemittance> BankRemittance { get; set; }
        public DbSet<BambooHRIntegrationLogs> BambooHRIntegrationLogs { get; set; }
        public DbSet<LeavePassageAmounts> LeavePassageAmounts { get; set; }
        public DbSet<RentFreeQuarterAllowance> RentFreeQuarterAllowance { get; set; }

        public DbSet<AssetTypes> AssetTypes { get; set; }
        public DbSet<Assets> Assets { get; set; }
        public DbSet<AssetAssignments> AssetAssignments { get; set; }
        public DbSet<EmployeeQualifications> EmployeeQualifications { get; set; }
        public DbSet<EmployeeExperiences> EmployeeExperiences { get; set; }
        public DbSet<QualificationTypes> QualificationTypes { get; set; }
        public DbSet<EmployeeActions> EmployeeActions { get; set; }
        public DbSet<Countries> Countries { get; set; }
        public DbSet<EmployeeDocuments> EmployeeDocuments { get; set; }
        public DbSet<DocumentTypes> DocumentTypes { get; set; }
        public DbSet<EmployeeTypes> EmployeeTypes { get; set; }

        #region Office Management
        public DbSet<OfficeTypes> OfficeTypes { get; set; }
        public DbSet<EmployeeStatutoryDetails> EmployeeStatutoryDetails { get; set; }
        public DbSet<States> States { get; set; }
        public DbSet<Offices> Offices { get; set; }
        public DbSet<EmployeeOfficePostings> EmployeeOfficePostings { get; set; }
        #endregion

        public DbSet<Nationalities> Nationalities { get; set; }
        public DbSet<UserLastActivity> UserLastActivity { get; set; }

        #region Time & Attendance
        public DbSet<ShiftDefinitionEntity> ShiftDefinitions { get; set; }
        public DbSet<ShiftSchedule> ShiftSchedules { get; set; }
        public DbSet<ShiftEmployee> ShiftEmployees { get; set; }
        public DbSet<ShiftAssignment> ShiftAssignments { get; set; }
        public DbSet<DayAttendance> DayAttendance { get; set; }
        public DbSet<ClockInOutDetails> ClockInOutDetails { get; set; }
        public DbSet<EmployeeUnauthorizedAbsence> EmployeeUnAuthorizedAbsence { get; set; }

        #endregion

        #region
        // Leave Master
        public DbSet<LeaveTypes> LeaveTypes { get; set; }

        // Annual Leave Configuration
        public DbSet<AnnualLeaveTypeConfig> AnnualLeaveTypeConfig { get; set; }

        // Leave Templates
        public DbSet<LeaveTemplates> LeaveTemplates { get; set; }
        public DbSet<LeaveTemplateDetails> LeaveTemplateDetails { get; set; }

        // Employee Leave Configuration
        public DbSet<EmployeeLeaveConfigs> EmployeeLeaveConfigs { get; set; }
        public DbSet<EmployeeLeaveConfigDetails> EmployeeLeaveConfigDetails { get; set; }

        // Leave Applications
        public DbSet<LeaveApplications> LeaveApplications { get; set; }
        public DbSet<VwLeaveApplication> VwLeaveApplications { get; set; }
        public DbSet<LeaveApplicationDocuments> LeaveApplicationDocuments { get; set; }
        public DbSet<EmployeeServiceChanges> EmployeeServiceChanges { get; set; }

        public DbSet<ExitReasons> ExitReasons { get; set; }
        public DbSet<ExitTypes> ExitTypes { get; set; }
        public DbSet<ExitCases> ExitCases { get; set; }
        public DbSet<NoticePeriodPolicies> NoticePeriodPolicies { get; set; }
        public DbSet<ClearanceTemplates> ClearanceTemplates { get; set; }
        public DbSet<ClearanceTemplateDepartments> ClearanceTemplateDepartments { get; set; }
        public DbSet<ExitCaseStatusHistory> ExitCaseStatusHistory { get; set; }
        public DbSet<ExitCaseClearanceAssignment> ExitCaseClearanceAssignments { get; set; }
        public DbSet<ExitCaseDepartmentClearanceLine> ExitCaseDepartmentClearanceLines { get; set; }
        public DbSet<MobileNotifications> MobileNotifications { get; set; }
        public DbSet<AuditLogs> AuditLog { get; set; }
        public DbSet<EmployeeHierarchyView> EmployeeHierarchyView { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EmployeeShiftResult>()
            .HasNoKey().ToView(null);
            modelBuilder.Entity<EmployeeHierarchyView>()
                .HasNoKey()
                .ToView("vw_EmployeeHierarchy");
            modelBuilder.Entity<ShiftDefinitionEntity>(entity =>
            {
                entity.HasKey(e => e.IdShift);

                entity.Property(e => e.IdShift)
                      .ValueGeneratedOnAdd();  // important
            });

            // the events table has a trigger that blocks UPDATE / DELETE
            modelBuilder.Entity<EmployeeAgreementEvents>().ToTable(tb => tb.HasTrigger("TR_EmployeeAgreementEvents_NoChange"));
            modelBuilder.Entity<GeneralDocumentAudit>().ToTable("GeneralDocumentAudit", tb => tb.HasTrigger("TR_GeneralDocumentAudit_NoChange"));
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<EmployeeShiftResult> EmployeeShiftResults { get; set; } // add this

        #endregion

        #region BambooHR
        public DbSet<EmployeeLeave> EmployeeLeaves { get; set; }
        public DbSet<EmployeeLeaveDetail> EmployeeLeaveDetails { get; set; }
        public DbSet<BambooHRLeaveIntegrationLastRun> BambooHRLeaveIntegrationLastRun { get; set; }
        public DbSet<EmployeeChildren> EmployeeChildren { get; set; }


        #endregion

    }
}

