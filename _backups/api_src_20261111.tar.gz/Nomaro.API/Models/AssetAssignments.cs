﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Nomaro.API.Models
{
    public class AssetAssignments
    {
        [Key]
        public int IdAssetAssignment { get; set; }
        public int IdAsset { get; set; }
        // NULL when the asset is allocated only to an office
        public int? IdEmployee { get; set; }
        public DateTime AssignedDate { get; set; }
        public DateTime? AssignedTillDate { get; set; }
        public string? Remarks { get; set; }
        public int AssignedBy { get; set; }
        public DateTime AssignedDateTime { get; set; }
        public int? IdOffice { get; set; }
        [ForeignKey("IdAsset")]
        public virtual Assets Asset { get; set; }

    }
}
