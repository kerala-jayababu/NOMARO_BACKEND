﻿using Asp.Versioning;
using FluentValidation;
using Nomaro.API.DTO;
using Nomaro.API.Services.Interface;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Text.RegularExpressions;

namespace Nomaro.API.Controllers
{
    [ApiController]
    [ApiVersion(1)]
    
    [Route("/api/v{v:apiVersion}/[controller]")]
    public class EmployeeSalaryConfigController : ControllerBase
    {
        private readonly IEmployeeSalaryConfigService _employeeSalaryConfigService;
        private readonly IValidator<EmployeeSalaryConfigDto> _configValidator;
        private readonly IValidator<EmployeeSalaryConfigDetailsDto> _detailsValidator;
        private readonly ISalaryHeadServices _salaryservice;
        private readonly IConfiguration _configuration;
        private readonly IRoleBasedScreenService _roleBasedService;
        public EmployeeSalaryConfigController(
            IEmployeeSalaryConfigService employeeSalaryConfigService,
            IValidator<EmployeeSalaryConfigDto> configValidator,
            IValidator<EmployeeSalaryConfigDetailsDto> detailsValidator,
              IConfiguration configuration, IRoleBasedScreenService roleBasedService,
            ISalaryHeadServices salaryservice)
        {
            _employeeSalaryConfigService = employeeSalaryConfigService;
            _configValidator = configValidator;
            _detailsValidator = detailsValidator;
            _configuration = configuration;
            _roleBasedService = roleBasedService;
            _salaryservice = salaryservice;
        }

        #region EmployeeSalaryConfig

        [HttpGet("GetAllEmployeeSalaryConfig")]
        public async Task<IActionResult> GetAllEmployeeSalaryConfig(string? searchText = null,  string? dropdownFilter = null, DateTime? date = null)
         {
            try
            {
                var configs = await _employeeSalaryConfigService.GetAllConfigs(searchText, dropdownFilter,date);
                if (configs == null || !configs.Any())
                {
                    return Ok(ApiResponseDto<IEnumerable<EmployeeSalaryConfigDto>>.CreateSuccess(Enumerable.Empty<EmployeeSalaryConfigDto>(), "No configurations found."));
                }
                // Count distinct employees with Approved config
                int approvedCount = configs
                    .Where(x => x.ApprovalStatus == "APPROVED")
                    .Select(x => x.IdEmployee)
                    .Distinct()
                    .Count();
                int submittedCount = configs
                 .Where(x => x.ApprovalStatus == "SUBMITTED" || x.ApprovalStatus == "INTERIM APPROVED")
                 .Select(x => x.IdEmployee)
                 .Distinct()
                 .Count();
                    int rejectedCount = configs
              .Where(x => x.ApprovalStatus == "REJECTED")
              .Select(x => x.IdEmployee)
              .Distinct()
              .Count();
                // Total distinct employees in the result
                int totalEmployees = configs
                    .Select(x => x.IdEmployee)
                    .Distinct()
                    .Count();

                int notApprovedCount = totalEmployees - approvedCount;
                configs.First().ApprovedCount = approvedCount;
                configs.First().NotApprovedCount = notApprovedCount;
                configs.First().submittedCount = submittedCount;
                configs.First().rejectedCount = rejectedCount;
                //configs.First().notConfiguredCount = await _employeeSalaryConfigService.GetNotConfiguredEmployeeCount();
                return Ok(ApiResponseDto<IEnumerable<EmployeeSalaryConfigDto>>.CreateSuccess(configs, "EmployeeSalaryConfig retrieved successfully."));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        [HttpGet("GetEmployeeSalaryConfigById")]
        public async Task<IActionResult> GetEmployeeSalaryConfigById(int id)
        {
            try
            {
                var config = await _employeeSalaryConfigService.GetConfigById(id);
                if (config == null)
                {
                    return Ok(ApiResponseDto<EmployeeSalaryConfigDto>.CreateSuccess(null, "Configuration not found."));
                }

                return Ok(ApiResponseDto<EmployeeSalaryConfigDto>.CreateSuccess(config, "EmployeeSalaryConfigById retrieved successfully."));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        /// <summary>
        /// Latest approved salary configuration for an employee (by ValidFrom), including details and approval timeline for the latest workflow cycle.
        /// </summary>
        [HttpGet("GetLatestApprovedEmployeeSalaryConfigByEmployeeId")]
        public async Task<IActionResult> GetLatestApprovedEmployeeSalaryConfigByEmployeeId(int idEmployee)
        {
            try
            {
                var result = await _employeeSalaryConfigService.GetLatestApprovedConfigByEmployeeId(idEmployee);
                if (result == null || result.Config == null)
                {
                    return Ok(ApiResponseDto<LatestApprovedEmployeeSalaryConfigResponseDto>.CreateSuccess(null, "No approved salary configuration found for this employee."));
                }

                return Ok(ApiResponseDto<LatestApprovedEmployeeSalaryConfigResponseDto>.CreateSuccess(result, "Latest approved employee salary configuration retrieved successfully."));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        [HttpGet("GetAllEmployeeSalaryConfigSp")]
        public async Task<IActionResult> GetAllEmployeeSalaryConfigSp(string? searchText = null, string? dropdownFilter = null, bool isLatest = true)
        {
            try
            {
                var configs = await _employeeSalaryConfigService.GetAllConfigsSp(searchText, dropdownFilter, isLatest);
                if (configs == null || !configs.Any())
                {
                    return Ok(ApiResponseDto<IEnumerable<EmployeeSalaryConfigDto>>.CreateSuccess(Enumerable.Empty<EmployeeSalaryConfigDto>(), "No configurations found."));
                }

                // Count distinct employees with Approved config
                int approvedCount = configs
                    .Where(x => x.ApprovalStatus == "APPROVED")
                    .Select(x => x.IdEmployee)
                    .Distinct()
                    .Count();
                int submittedCount = configs
                 .Where(x => x.ApprovalStatus == "SUBMITTED" || x.ApprovalStatus == "INTERIM APPROVED")
                 .Select(x => x.IdEmployee)
                 .Distinct()
                 .Count();
                int rejectedCount = configs
              .Where(x => x.ApprovalStatus == "REJECTED")
              .Select(x => x.IdEmployee)
              .Distinct()
              .Count();
                int notConfigCount = configs
        .Where(x => x.ApprovalStatus == "Not Configured")
        .Select(x => x.IdEmployee)
        .Distinct()
        .Count();
                // Total distinct employees in the result
                int totalEmployees = configs
                    .Select(x => x.IdEmployee)
                    .Distinct()
                    .Count();

                int notApprovedCount = totalEmployees - approvedCount;
                configs.First().ApprovedCount = approvedCount;
                configs.First().NotApprovedCount = notApprovedCount;
                configs.First().submittedCount = submittedCount;
                configs.First().rejectedCount = rejectedCount;
                configs.First().notConfiguredCount = notConfigCount;

                return Ok(ApiResponseDto<IEnumerable<EmployeeSalaryConfigDto>>.CreateSuccess(configs, "EmployeeSalaryConfig (SP) retrieved successfully."));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        [HttpPost("AddEmployeeSalaryConfig")]
        public async Task<IActionResult> AddEmployeeSalaryConfig([FromBody] EmployeeSalaryConfigDto dto)
        {
            var validationResult = await _configValidator.ValidateAsync(dto);
            if (!validationResult.IsValid)
            {
                var errors = string.Join(", ", validationResult.Errors.Select(e => e.ErrorMessage));
                return BadRequest(ApiResponseDto<string>.CreateFailure($"Validation failed: {errors}"));
            }
            var IdEmployee = HttpContext.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(IdEmployee))
            {
                return Unauthorized(ApiResponseDto<string>.CreateFailure("Employee ID not found."));
            }
            if (dto.EmployeeSalaryConfigDetails != null)
            {
                foreach (var detail in dto.EmployeeSalaryConfigDetails)
                {
                    var detailValidationResult = await _detailsValidator.ValidateAsync(detail);
                    if (!detailValidationResult.IsValid)
                    {
                        var detailErrors = string.Join(", ", detailValidationResult.Errors.Select(e => e.ErrorMessage));
                        return BadRequest(ApiResponseDto<string>.CreateFailure($"Validation failed for Salary Config Details: {detailErrors}"));
                    }
                }
            }
            var screenCode = _configuration["ScreenCodes:EmployeeSalaryConfig"];
            var actionType = "A";

            // Check permission
            var hasPermission = await _roleBasedService.CheckEmployeePermission(int.Parse(IdEmployee), screenCode, actionType);

            if (!hasPermission)
            {
                return StatusCode(403, ApiResponseDto<string>.CreateFailure("You do not have the required permission to perform this action."));

            }

            try
            {
                //var IdEmployee = HttpContext.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var result = await _employeeSalaryConfigService.AddConfig(dto,int.Parse(IdEmployee));
                if (result == null)
                    return StatusCode(500, ApiResponseDto<string>.CreateFailure("Failed to add configuration."));
                return Ok(ApiResponseDto<List<string>>.CreateSuccess(result.Warnings ?? new List<string>(),
                    BuildSavedMessage("EmployeeSalaryConfig added successfully.", result.Warnings)));
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ApiResponseDto<string>.CreateFailure(ex.Message));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        [HttpPost("UpdateEmployeeSalaryConfig")]
        public async Task<IActionResult> UpdateEmployeeSalaryConfig([FromBody] EmployeeSalaryConfigDto dto)
        {
            var validationResult = await _configValidator.ValidateAsync(dto);
            if (!validationResult.IsValid)
            {
                var errors = string.Join(", ", validationResult.Errors.Select(e => e.ErrorMessage));
                return BadRequest(ApiResponseDto<string>.CreateFailure($"Validation failed: {errors}"));
            }
            var IdEmployee = HttpContext.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(IdEmployee))
            {
                return Unauthorized(ApiResponseDto<string>.CreateFailure("Employee ID not found."));
            }
            var screenCode = _configuration["ScreenCodes:EmployeeSalaryConfig"];
            var actionType = "U";

            // Check permission
            var hasPermission = await _roleBasedService.CheckEmployeePermission(int.Parse(IdEmployee), screenCode, actionType);

            if (!hasPermission)
            {
                return StatusCode(403, ApiResponseDto<string>.CreateFailure("You do not have the required permission to perform this action."));

            }
            if (dto.EmployeeSalaryConfigDetails != null)
            {
                foreach (var detail in dto.EmployeeSalaryConfigDetails)
                {
                    var detailValidationResult = await _detailsValidator.ValidateAsync(detail);
                    if (!detailValidationResult.IsValid)
                    {
                        var detailErrors = string.Join(", ", detailValidationResult.Errors.Select(e => e.ErrorMessage));
                        return BadRequest(ApiResponseDto<string>.CreateFailure($"Validation failed for Salary Config Details: {detailErrors}"));
                    }
                }
            }

            try
            {

                //var IdEmployee = HttpContext.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var result = await _employeeSalaryConfigService.UpdateConfig(dto, int.Parse(IdEmployee));
                if (result == null)
                    return NotFound(ApiResponseDto<string>.CreateFailure("Configuration not found."));
                return Ok(ApiResponseDto<List<string>>.CreateSuccess(result.Warnings ?? new List<string>(),
                    BuildSavedMessage("EmployeeSalaryConfig updated successfully.", result.Warnings)));

            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ApiResponseDto<string>.CreateFailure(ex.Message));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        /// <summary>
        /// Sets approval status to SUBMITTED, restarts the approval workflow, and writes an audit log (before/after snapshot).
        /// </summary>
        [HttpPost("UnApproveEmployeeSalaryConfig")]
        public async Task<IActionResult> UnApproveEmployeeSalaryConfig([FromBody] SubmitEmployeeSalaryConfigForApprovalDto request)
        {
            if (request == null || request.IdEmployeeSalaryConfig <= 0)
            {
                return BadRequest(ApiResponseDto<string>.CreateFailure("IdEmployeeSalaryConfig is required."));
            }

            var idEmployeeClaim = HttpContext.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(idEmployeeClaim) || !int.TryParse(idEmployeeClaim, out var idEmployee))
            {
                return Unauthorized(ApiResponseDto<string>.CreateFailure("Employee ID not found."));
            }

            var screenCode = _configuration["ScreenCodes:EmployeeSalaryConfig"];
            var actionType = "U";
            var hasPermission = await _roleBasedService.CheckEmployeePermission(idEmployee, screenCode, actionType);
            if (!hasPermission)
            {
                return StatusCode(403, ApiResponseDto<string>.CreateFailure("You do not have the required permission to perform this action."));
            }

            try
            {
                var result = await _employeeSalaryConfigService.UnApproveEmployeeSalaryConfig(request.IdEmployeeSalaryConfig, idEmployee);
                if (result == null)
                {
                    return NotFound(ApiResponseDto<string>.CreateFailure("Salary configuration not found."));
                }

                return Ok(ApiResponseDto<EmployeeSalaryConfigDto>.CreateSuccess(result, "Configuration submitted for approval successfully."));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        /// <summary>
        /// Header line after an employee is selected: current structure's Valid From and net, whether a structure is
        /// waiting for approval, and the default Valid From / Revision Reason.
        /// </summary>
        [HttpGet("GetEmployeeSalaryStructureInfo")]
        public async Task<IActionResult> GetEmployeeSalaryStructureInfo(int idEmployee)
        {
            if (idEmployee <= 0)
            {
                return BadRequest(ApiResponseDto<string>.CreateFailure("Select an employee."));
            }

            try
            {
                var info = await _employeeSalaryConfigService.GetEmployeeSalaryStructureInfo(idEmployee);
                return Ok(ApiResponseDto<EmployeeSalaryStructureInfoDto>.CreateSuccess(info, "Employee salary structure information retrieved successfully."));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        /// <summary>
        /// Calculates the grid (Calculated Value per row and the totals line) the same way the salary procedure does.
        /// Call it after every change on the Employee Salary Config screen. Nothing is saved.
        /// </summary>
        [HttpPost("CalculateSalaryStructure")]
        public async Task<IActionResult> CalculateSalaryStructure([FromBody] SalaryStructureCalculationRequestDto request)
        {
            if (request == null || request.Rows == null)
            {
                return BadRequest(ApiResponseDto<string>.CreateFailure("Invalid input."));
            }

            try
            {
                var result = await _employeeSalaryConfigService.CalculateSalaryStructure(request.Rows);
                return Ok(ApiResponseDto<SalaryStructureResultDto>.CreateSuccess(result,
                    result.Errors.Any() ? string.Join(" ", result.Errors) : "Salary structure calculated successfully."));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponseDto<string>.CreateFailure($"An error occurred: {ex.Message}"));
            }
        }

        private static string BuildSavedMessage(string message, List<string>? warnings) =>
            warnings != null && warnings.Any() ? $"{message} {string.Join(" ", warnings)}" : message;

        #endregion

     
    }
}

